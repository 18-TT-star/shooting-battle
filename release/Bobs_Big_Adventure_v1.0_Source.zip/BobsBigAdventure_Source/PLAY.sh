#!/bin/bash
cd "$(dirname "$0")"
python3 setup_and_play.py
